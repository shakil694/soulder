#!/usr/bin/env python2
# -*- coding: utf-8 -*-
# pylint: skip-file

ALL_2G_CHANNELS = range(1, 14)
